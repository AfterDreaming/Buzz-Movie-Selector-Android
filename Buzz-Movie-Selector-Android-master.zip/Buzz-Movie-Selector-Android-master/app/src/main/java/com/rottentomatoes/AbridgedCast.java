
package com.rottentomatoes;

import com.google.gson.annotations.Expose;
import java.io.Serializable;


/**
 * This class represents abridged cast
 */
//@Generated("org.jsonschema2pojo")
public class AbridgedCast implements Serializable {
    private static final long serialVersionUID = -403250971215465050L;

    @Expose
    private String name;
    @Expose
    private String id;

    /**
     * Get name
     * @return
     *     The name
     */
    public String getName() {
        return name;
    }

    /**
     * Set name
     * @param name
     *     The name
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Get ID
     * @return
     *     The id
     */
    public String getId() {
        return id;
    }

    /**
     * Set ID
     * @param id
     *     The id
     */
    public void setId(String id) {
        this.id = id;
    }
}
