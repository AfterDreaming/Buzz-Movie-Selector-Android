
package com.rottentomatoes;


import com.google.gson.annotations.Expose;
import java.io.Serializable;


/**
 * This class represents ReleaseDates
 * @author Lance
 */
//@Generated("org.jsonschema2pojo")
public class ReleaseDates implements Serializable {
    private static final long serialVersionUID = -403250971215465050L;

    @Expose
    private String theater;

    /**
     * Get the theater
     * @return
     *     The theater
     */
    public String getTheater() {
        return theater;
    }

    /** 
     * Set the theater
     * @param theater
     *     The theater
     */
    public void setTheater(String theater) {
        this.theater = theater;
    }
    

}
