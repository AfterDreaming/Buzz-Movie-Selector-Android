
package com.rottentomatoes;

import com.google.gson.annotations.Expose;
import java.io.Serializable;

/**
 * This class represents links
 */
//@Generated("org.jsonschema2pojo")
public class Links implements Serializable {
    private static final long serialVersionUID = -403250971215465050L;
    
    @Expose
    private String self;
    @Expose
    private String alternate;
    @Expose
    private String cast;
    @Expose
    private String reviews;
    @Expose
    private String similar;

    /**
     * Get self
     * @return
     *     The self
     */
    public String getSelf() {
        return self;
    }

    /**
     * Set self
     * @param self
     *     The self
     */
    public void setSelf(String self) {
        this.self = self;
    }

    /**
     * Get alternative
     * @return
     *     The alternate
     */
    public String getAlternate() {
        return alternate;
    }

    /**
     * Set alternative
     * @param alternate
     *     The alternate
     */
    public void setAlternate(String alternate) {
        this.alternate = alternate;
    }

    /**
     * Get cast
     * @return
     *     The cast
     */
    public String getCast() {
        return cast;
    }

    /**
     * Set cast
     * @param cast
     *     The cast
     */
    public void setCast(String cast) {
        this.cast = cast;
    }

    /**
     * Get reviews
     * @return
     *     The reviews
     */
    public String getReviews() {
        return reviews;
    }

    /**
     * Set reviews
     * @param reviews
     *     The reviews
     */
    public void setReviews(String reviews) {
        this.reviews = reviews;
    }

    /**
     * Get similar
     * @return
     *     The similar
     */
    public String getSimilar() {
        return similar;
    }

    /**
     * Set similar
     * @param similar
     *     The similar
     */
    public void setSimilar(String similar) {
        this.similar = similar;
    }


}
