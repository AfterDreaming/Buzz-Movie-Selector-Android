
package com.rottentomatoes;


import com.google.gson.annotations.Expose;
import java.io.Serializable;

/**
 * This class represents alternative ID
 */
//@Generated("org.jsonschema2pojo")
public class AlternateIds implements Serializable {
    private static final long serialVersionUID = -403250971215465050L;

    @Expose
    private String imdb;

    /**
     * Get IMBD
     * @return
     *     The imdb
     */
    public String getImdb() {
        return imdb;
    }

    /**
     * Set IMDB
     * @param imdb
     *     The imdb
     */
    public void setImdb(String imdb) {
        this.imdb = imdb;
    }


}
