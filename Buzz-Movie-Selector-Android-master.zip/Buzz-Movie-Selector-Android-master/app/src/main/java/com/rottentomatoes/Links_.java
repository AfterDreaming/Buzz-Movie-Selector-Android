
package com.rottentomatoes;

import com.google.gson.annotations.Expose;

/**
 * This class represents links_
 */
//@Generated("org.jsonschema2pojo")
public class Links_ {

    @Expose
    private String self;
    @Expose
    private String next;

    /**
     * Get self
     * @return
     *     The self
     */
    public String getSelf() {
        return self;
    }

    /**
     * Set self
     * @param self
     *     The self
     */
    public void setSelf(String self) {
        this.self = self;
    }

    /**
     * Get next
     * @return
     *     The next
     */
    public String getNext() {
        return next;
    }

    /**
     * Set next
     * @param next
     *     The next
     */
    public void setNext(String next) {
        this.next = next;
    }


}
