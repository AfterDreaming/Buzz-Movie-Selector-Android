package com.zhuangyufan.myapplication;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


/**
 * Database class helps to make the connection to mysql database
 *
 * @author Yufan
 */
public class Database {

    /**
     * Get the connection to database
     *
     * @return Connection a connection to database
     */
    public static Connection openConnection() {
        String driver = "com.mysql.jdbc.Driver";
        String url = "jdbc:mysql://sql3.freemysqlhosting.net:3306/sql379635?useUnicode=true&characterEncoding=utf-8";
        String username = "sql379635";
        String password = "tR8!yN9*";
        Connection con = null;
        try {
            Class.forName(driver);
            con =  DriverManager.getConnection(url, username, password);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            return con;
        }

    }

    /**
     * Close the connection which was opened before
     *
     * @param conn
     */
    public static void closeConn(Connection conn) {
        try {
            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
