package com.zhuangyufan.myapplication;

import android.app.Activity;
import android.content.Intent;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;


public class Home extends Activity implements View.OnClickListener {
    Button profileButton;
    Button newDVDsButton;
    Button newReleaseButton;
    Button searchButton;
    Button logoutButton;
    Button youmaylikeButton;
    String username;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        Intent intent = getIntent();
        username = intent.getStringExtra("name");
        //currentUser = UserManager.searchUserWithName(username);

        profileButton = (Button) findViewById(R.id.profile);
        profileButton.setOnClickListener(this);
        newDVDsButton = (Button) findViewById(R.id.newDVD);
        newDVDsButton.setOnClickListener(this);
        newReleaseButton = (Button) findViewById(R.id.newRelease);
        newReleaseButton.setOnClickListener(this);
        searchButton = (Button) findViewById(R.id.search);
        searchButton.setOnClickListener(this);
        youmaylikeButton = (Button) findViewById(R.id.youmaylike);
        youmaylikeButton.setOnClickListener(this);
        logoutButton = (Button) findViewById(R.id.logout);
        logoutButton.setOnClickListener(this);
    }
    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.newDVD) {
            Intent intentR = new Intent(this, NewDVDsActivity.class);
            intentR.putExtra("name",username);
            startActivity(intentR);
        }
        if (v.getId() == R.id.newRelease) {
            Intent intentR = new Intent(this, NewReleaseActivity.class);
            intentR.putExtra("name",username);
            startActivity(intentR);
        }

        if (v.getId() == R.id.search) {
            Intent intentR = new Intent(this, SearchActivity.class);
            intentR.putExtra("name",username);
            startActivity(intentR);
        }
        if (v.getId() == R.id.profile) {
            Intent intentR = new Intent(this, ProfileActivity.class);
            intentR.putExtra("name",username);
            startActivity(intentR);
        }
        if (v.getId() == R.id.logout) {
            startActivity(new Intent(this, MainActivity.class));
        }
        if (v.getId() == R.id.youmaylike) {
            Intent intentR = new Intent(this, YouMayLikeActivity.class);
            intentR.putExtra("name",username);
            startActivity(intentR);
        }
    }
}
