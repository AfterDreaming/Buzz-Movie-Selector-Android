
package com.zhuangyufan.myapplication;

import java.io.Serializable;

/**
 * The Rating class is to store the information of user's rating
 * @author Yufan
 */
public class BuzzRating implements Serializable {
    private String movieId;
    private int scores;
    private String comments;
    private String username;
    private static final long serialVersionUID = -403250971215465050L;

    
    public String getMovieId() {
        return movieId;
    }

    public void setMovieId(String movieId) {
        this.movieId = movieId;
    }

    public int getScores() {
        return scores;
    }

    public void setScores(int scores) {
        this.scores = scores;
    }

    public String getComments() {
        return comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String u) {
        this.username = u;
    }

    public String toString(){
        return comments;
    }
}
