package com.zhuangyufan.myapplication;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.RatingBar;
import android.widget.TextView;

import com.rottentomatoes.Movie;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;


public class MovieDetailsActivity extends ActionBarActivity implements View.OnClickListener {
    private Movie movie;
    private String movieid;
    private List<BuzzRating> ratings;
    ListView commentsListView;
    TextView titleView;
    ImageView imageView;
    EditText commentView;
    Button submitButton;
    String username;
    RatingBar ratingBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_movie_details);
        Intent intent = getIntent();
        username = intent.getStringExtra("name");
        movieid = intent.getStringExtra("movieid");
        commentsListView = (ListView) findViewById(R.id.commlistView);
        titleView = (TextView) findViewById(R.id.titleView);
        imageView = (ImageView) findViewById(R.id.imageView);
        commentView = (EditText) findViewById(R.id.commentTextView);
        submitButton = (Button) findViewById(R.id.submitButton);
        submitButton.setOnClickListener(this);
        ratingBar = (RatingBar) findViewById(R.id.ratingBar);
        new MovieDetailsTask().execute();
    }
    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.submitButton) {
            new SubmitCommentTask().execute();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_movie_details, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
    public class MovieDetailsTask extends AsyncTask<Void, Void, Boolean> {
        boolean result;
        ArrayAdapter<BuzzRating> itemsAdapter;

        @Override
        protected void onPreExecute() {

        }

        @Override
        protected Boolean doInBackground(Void... params) {
            RottenTomatoes rt = new RottenTomatoes();
            movie = rt.getMovieById(movieid);
            ratings = RatingManager.getRatings(movieid);
            itemsAdapter = new ArrayAdapter<>(MovieDetailsActivity.this,
                    android.R.layout.simple_list_item_1, ratings);
            return result;
        }

        @Override
        protected void onPostExecute(final Boolean success) {
            commentsListView.setAdapter(itemsAdapter);
            titleView.setText(movie.getTitle());
            new ImageLoadTask(movie.getPosters().getDetailed(), imageView).execute();
        }
    }

    public class SubmitCommentTask extends AsyncTask<Void, Void, Boolean> {
        boolean result;
        @Override
        protected void onPreExecute() {

        }

        @Override
        protected Boolean doInBackground(Void... params) {
            RatingManager.addRating(ratingBar.getNumStars(),commentView.getText().toString(),movie.getId(),username);
            return result;
        }

        @Override
        protected void onPostExecute(final Boolean success) {
            finish();
            startActivity(getIntent());
        }
    }
}
