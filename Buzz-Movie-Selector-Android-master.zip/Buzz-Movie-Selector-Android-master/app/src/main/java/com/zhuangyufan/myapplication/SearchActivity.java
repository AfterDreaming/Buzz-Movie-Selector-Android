package com.zhuangyufan.myapplication;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.SearchView;
import android.widget.TextView;

import com.rottentomatoes.Movie;

import java.util.List;


public class SearchActivity extends ActionBarActivity implements View.OnClickListener{
    List<Movie> movies;
    ListView movieListView;
    EditText searchView;
    String keyword;
    Button searchBtn;
    String username;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);
        Intent intent = getIntent();
        username = intent.getStringExtra("name");
        searchView = (EditText) findViewById(R.id.searchText);
        movieListView = (ListView) findViewById(R.id.movieList);
        searchBtn = (Button) findViewById(R.id.searchButton);
        searchBtn.setOnClickListener(this);

    }
    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.searchButton) {
            new SearchTask().execute();

        }
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_search, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    public class SearchTask extends AsyncTask<Void, Void, Boolean> {
        boolean result;
        ArrayAdapter<Movie> itemsAdapter;

        @Override
        protected void onPreExecute() {
            keyword = searchView.getText().toString();
        }

        @Override
        protected Boolean doInBackground(Void... params) {
            RottenTomatoes rt = new RottenTomatoes();
            movies = rt.searchMovies(keyword);
            itemsAdapter = new ArrayAdapter<>(SearchActivity.this,
                    android.R.layout.simple_list_item_1, movies);

            return result;
        }

        @Override
        protected void onPostExecute(final Boolean success) {
            movieListView.setAdapter(itemsAdapter);
            movieListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view,
                                        int position, long id) {
                    Movie clickedMovie = (Movie) parent.getItemAtPosition(position);
                    String movieid = clickedMovie.getId();
                    Intent intent = new Intent(SearchActivity.this, MovieDetailsActivity.class);
                    intent.putExtra("movieid", movieid);
                    intent.putExtra("name",username);
                    startActivity(intent);
                }
            });

        }
    }
}
