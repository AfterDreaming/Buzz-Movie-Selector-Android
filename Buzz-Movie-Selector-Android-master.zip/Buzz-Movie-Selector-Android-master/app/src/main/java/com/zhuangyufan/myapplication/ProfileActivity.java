package com.zhuangyufan.myapplication;

import android.app.Activity;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;


public class ProfileActivity extends Activity implements View.OnClickListener {

//    TextView firstname;
//    TextView lastname;
//    TextView major;
//    TextView interest;
    User currentUser;
    EditText firstnameField;
    EditText lastnameField;
    EditText interestField;
    Spinner majorSpinner;
    Button confirmButton;
    String username;
    String firstname;
    String lastname;
    String interest;
    String major;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);
        username = getIntent().getStringExtra("name");

        firstnameField = (EditText) findViewById(R.id.EditTextName1);
        lastnameField = (EditText) findViewById(R.id.EditTextName2);
        interestField = (EditText) findViewById(R.id.Interest);
        majorSpinner = (Spinner) findViewById(R.id.SpinnerMajor);
        confirmButton = (Button) findViewById(R.id.Confirm);
        confirmButton.setOnClickListener(this);
        new UserProfileTask().execute();
        firstname = firstnameField.getText().toString();
        lastname = lastnameField.getText().toString();
        interest = interestField.getText().toString();
        major = majorSpinner.getSelectedItem().toString();

    }
    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.Confirm) {
            new UpdateProfileTask().execute();
        }
    }

    public class UserProfileTask extends AsyncTask<Void, Void, Boolean> {
        boolean result;
        @Override
        protected void onPreExecute() {

        }

        @Override
        protected Boolean doInBackground(Void... params) {
            currentUser = UserManager.searchUserWithName(username);
            return result;
        }

        @Override
        protected void onPostExecute(final Boolean success) {
            firstnameField.setText(currentUser.getFirstname());
            lastnameField.setText(currentUser.getLastname());
            interestField.setText(currentUser.getInterest());
            majorSpinner.setSelection(getIndex(majorSpinner, currentUser.getMajor()));
        }
    }

    public class UpdateProfileTask extends AsyncTask<Void, Void, Boolean> {

        boolean result;
        @Override
        protected void onPreExecute() {
            currentUser.setFirstname(firstnameField.getText().toString());
            currentUser.setLastname(lastnameField.getText().toString());
            currentUser.setInterest(interestField.getText().toString());
            currentUser.setMajor(majorSpinner.getSelectedItem().toString());
        }

        @Override
        protected Boolean doInBackground(Void... params) {
            UserManager.updateUser(currentUser);
            return result;
        }

        @Override
        protected void onPostExecute(final Boolean success) {
            finish();
            startActivity(getIntent());
        }
    }
    private int getIndex(Spinner spinner, String myString) {
        int index = 0;
        for (int i=0;i<spinner.getCount();i++){
            if (spinner.getItemAtPosition(i).toString().equalsIgnoreCase(myString)){
                index = i;
                break;
            }
        }
        return index;
    }
}
