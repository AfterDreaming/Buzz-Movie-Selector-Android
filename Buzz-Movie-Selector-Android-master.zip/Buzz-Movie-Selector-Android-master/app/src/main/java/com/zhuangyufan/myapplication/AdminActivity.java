package com.zhuangyufan.myapplication;

import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import com.rottentomatoes.Movie;

import java.util.ArrayList;
import java.util.List;


public class AdminActivity extends ActionBarActivity {
    List<User> users;
    ListView listView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin);
        listView = (ListView) findViewById(R.id.userListView);
        new AdminTask().execute();
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view,
                                    int position, long id) {
                User clickedUser = (User) parent.getItemAtPosition(position);
                String username = clickedUser.getUsername();
                Intent intent = new Intent(AdminActivity.this, UserDetailsActivity.class);
                intent.putExtra("name", username);
                startActivity(intent);
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_admin, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
    public class AdminTask extends AsyncTask<Void, Void, Boolean> {
        boolean result;
        ArrayAdapter<User> itemsAdapter;

        @Override
        protected void onPreExecute() {

        }

        @Override
        protected Boolean doInBackground(Void... params) {
            users = UserManager.getUserList();
            itemsAdapter = new ArrayAdapter<>(AdminActivity.this,
                            android.R.layout.simple_list_item_1, users);
            return result;
        }

        @Override
        protected void onPostExecute(final Boolean success) {
            listView.setAdapter(itemsAdapter);
        }
    }

}
