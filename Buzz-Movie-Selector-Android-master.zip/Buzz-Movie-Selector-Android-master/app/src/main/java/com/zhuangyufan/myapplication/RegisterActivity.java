package com.zhuangyufan.myapplication;

import android.app.Activity;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;


public class RegisterActivity extends Activity implements View.OnClickListener {
    private EditText inputEmail;
    private EditText inputPassword;
    private User registerUser;
    private Button signUpBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        inputEmail = (EditText) findViewById(R.id.registerEmail);
        inputPassword = (EditText) findViewById(R.id.registerPassword);
        signUpBtn = (Button) findViewById(R.id.signUpButton);
        signUpBtn.setOnClickListener(this);
    }


    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.signUpButton) {
            new UserRegisterTask().execute();
        }
    }


    /**
     * Async Login Task to authenticate
     */
    public class UserRegisterTask extends AsyncTask<Void, Void, Boolean> {

        String username;
        String pass;
        boolean result;
        @Override
        protected void onPreExecute() {
            username = inputEmail.getText().toString();
            pass = inputPassword.getText().toString();
        }

        @Override
        protected Boolean doInBackground(Void... params) {
            User newUser = new User(username,pass);
            UserManager.addUser(newUser);
            return result;
        }

        @Override
        protected void onPostExecute(final Boolean success) {
            login();
        }
    }
    private void login() {
        startActivity(new Intent(this, Home.class));
    }
}
