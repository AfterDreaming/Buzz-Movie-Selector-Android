package com.zhuangyufan.myapplication;

import android.app.Activity;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

/**
 * Android login screen Activity
 */
public class MainActivity extends Activity implements View.OnClickListener {

    private UserLoginTask userLoginTask = null;
    private EditText passwordTextView;
    private TextView signUpTextView;
    private EditText usernameTextView;
    private User loggedUser;
    Button loginButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        passwordTextView = (EditText) findViewById(R.id.password);
        usernameTextView = (EditText) findViewById(R.id.username);
        signUpTextView = (TextView) findViewById(R.id.signUpTextView);
        signUpTextView.setOnClickListener(this);
        loginButton = (Button) findViewById(R.id.login);
        loginButton.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.login) {
            new UserLoginTask().execute();
        }
        if (v.getId() == R.id.signUpTextView) {
            startActivity(new Intent(this, RegisterActivity.class));
        }
    }


    /**
     * Async Login Task to authenticate
     */
    public class UserLoginTask extends AsyncTask<Void, Void, Boolean> {

        String username;
        String pass;
        boolean result;
        @Override
        protected void onPreExecute() {
            username = usernameTextView.getText().toString();
            pass = passwordTextView.getText().toString();
        }

        @Override
        protected Boolean doInBackground(Void... params) {
            if(username.isEmpty() || pass.isEmpty()){
                Toast.makeText(MainActivity.this, "Please input the usernase and password", Toast.LENGTH_LONG).show();
            }else{
                loggedUser = UserManager.searchUser(username,pass);
            }
            return result;
        }

        @Override
        protected void onPostExecute(final Boolean success) {

            if (loggedUser == null) {
                //  login success and move to main Activity here.
                Toast.makeText(MainActivity.this, "User does not exist or password is wrong", Toast.LENGTH_LONG).show();
            } else {
                if(loggedUser.getRole() == 1){
                    adminLogin();
                }else {
                    if(loggedUser.getStatus().equals("Active")){
                        login();
                    }else{
                        Toast.makeText(MainActivity.this, "User has been banned or locked", Toast.LENGTH_LONG).show();
                    }
                }
            }
        }
    }

    private void login() {
        Intent intent = new Intent(this, Home.class);
        intent.putExtra("name",loggedUser.getUsername());
        startActivity(intent);
    }

    private void adminLogin() {
        startActivity(new Intent(this, AdminActivity.class));
    }
}