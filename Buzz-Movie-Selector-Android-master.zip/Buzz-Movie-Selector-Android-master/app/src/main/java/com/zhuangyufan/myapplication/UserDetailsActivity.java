package com.zhuangyufan.myapplication;

import android.os.AsyncTask;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;


public class UserDetailsActivity extends ActionBarActivity implements View.OnClickListener{
    User currentUser;

    Button confirmButton;
    String username;
    String status;
    TextView usernameField;
    TextView userstatusField;

    private RadioGroup radioStatusGroup;
    private RadioButton radioStatusButton;
    private Button btnDisplay;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_details);
        username = getIntent().getStringExtra("name");

        usernameField = (TextView) findViewById(R.id.usernameView);
        userstatusField = (TextView) findViewById(R.id.userstatusView);
        new UserProfileTask().execute();

        addListenerOnButton();

    }
    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.Confirm) {
            new UpdateProfileTask().execute();
        }
    }

    public class UserProfileTask extends AsyncTask<Void, Void, Boolean> {
        boolean result;
        @Override
        protected void onPreExecute() {
        }

        @Override
        protected Boolean doInBackground(Void... params) {
            currentUser = UserManager.searchUserWithName(username);
            return result;
        }

        @Override
        protected void onPostExecute(final Boolean success) {
            usernameField.setText("Username: " + currentUser.getUsername());
            userstatusField.setText("Status: " + currentUser.getStatus());
        }
    }


    public void addListenerOnButton() {

        radioStatusGroup = (RadioGroup) findViewById(R.id.radioStatus);
        btnDisplay = (Button) findViewById(R.id.confirmButton);
        btnDisplay.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                // get selected radio button from radioGroup
                int selectedId = radioStatusGroup.getCheckedRadioButtonId();

                // find the radiobutton by returned id
                radioStatusButton = (RadioButton) findViewById(selectedId);

                Toast.makeText(UserDetailsActivity.this,
                        radioStatusButton.getText(), Toast.LENGTH_SHORT).show();
                currentUser.setStatus(radioStatusButton.getText().toString());
                new UpdateProfileTask().execute();
            }

        });

    }
    public class UpdateProfileTask extends AsyncTask<Void, Void, Boolean> {

        boolean result;

        @Override
        protected void onPreExecute() {
        }

        @Override
        protected Boolean doInBackground(Void... params) {
            UserManager.updateUser(currentUser);
            return result;
        }

        @Override
        protected void onPostExecute(final Boolean success) {
            finish();
            startActivity(getIntent());
        }
    }
}